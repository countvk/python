import csv
import math as ma
import numpy as np
import matplotlib.pylab as plt
import time
#def trapz(b,a):
#    s = float(0)
#    for i in range(len(a)-1):
#        s = (a[i] + a[i+1])*(b[i+1]-b[i])
#    return s/2

                                                         # interpolation function
def interp(filename,w ):
    #read csv
    with open(filename,'r') as csvfile:
        reader = csv.reader(csvfile)
        wc = np.zeros(41)
        m1 = np.zeros(41)
        m2 = np.zeros(41)
        m3 = np.zeros(41)
        m4 = np.zeros(41)
        m5 = np.zeros(41)
        m6 = np.zeros(41)
        j = 0
        for row in reader:
            wc[j] = float(row[0])
            m1[j] = float(row[1])
            m2[j] = float(row[2])
            m3[j] = float(row[3])
            m4[j] = float(row[4])
            m5[j] = float(row[5])
            m6[j] = float(row[6])
            j += 1
    M = np.zeros(6)
    for i in range(1,j):
        if wc[i-1] < w and wc[i] > w:
            M[0] = (m1[i] - m1[i-1])*(w - wc[i-1])/(wc[i] - wc[i-1]) + m1[i-1]
            M[1] = (m2[i] - m2[i-1])*(w - wc[i-1])/(wc[i] - wc[i-1]) + m2[i-1]
            M[2] = (m3[i] - m3[i-1])*(w - wc[i-1])/(wc[i] - wc[i-1]) + m3[i-1]
            M[3] = (m4[i] - m4[i-1])*(w - wc[i-1])/(wc[i] - wc[i-1]) + m4[i-1]
            M[4] = (m5[i] - m5[i-1])*(w - wc[i-1])/(wc[i] - wc[i-1]) + m5[i-1]
            M[5] = (m6[i] - m6[i-1])*(w - wc[i-1])/(wc[i] - wc[i-1]) + m6[i-1]
            break
    return M

                                                         # Ainf and Btau function
def AnB(filename,mode,A,T,wv ):
    
    with open(filename,'r') as csvfile:
        reader = csv.reader(csvfile)
        w = np.zeros(26)
        B = np.zeros(26)
        i = 0
        for row in reader:
            w[i] = float(row[0])
            B[i] = float(row[mode])
            i += 1
    Btau = np.zeros(len(T))
    for i in range(len(T)):
        if i == 0:
            Btau[i] = np.trapz(B,w)
        else:
            Btauv = 0
            t = T[i]
            D = (B[1:len(B)] - B[0:len(B)-1])/(w[1:len(B)] - w[0:len(B)-1])
            
            Btau[i] = sum((np.cos(w[1:len(B)]*t) - np.cos(w[0:len(B)-1]*t))*(D/t**2))  + B[len(B)-1]*np.sin(w[len(B)-1]*t)/t
    Btau = (2/np.pi)*Btau
    
    #return Btau        
	#A is found by interp
    dt = T[1] - T[0]
    sum1 = 1/wv**2
    sum2 = (1/wv) *(Btau[0] - Btau[len(T)-1] * ma.cos(wv*T[len(T)-1]))
    #sum3 = 0
    #for i in range(0,len(T)-2):
    #   sum3 += (Btau[i+1] - Btau[i])*(np.sin(wv*T[i+1]) - np.sin(wv*T[i]))/dt
    sum3 = sum((Btau[1:len(T)] - Btau[0:len(T)-1])*(np.sin(wv*T[1:len(T)]) - np.sin(wv*T[0:len(T)-1])))/dt
    Ainf = A + (sum1*sum3 +sum2)
    return Ainf , Btau
                                                         # functions for finding modal displacement, BM and SF
alphaL = np.array([4.730, 7.853, 10.996, 14.137, 17.278, 20.420])
def modaldisp(mode,x,L = 120):
    global alphaL
    alpha = alphaL[mode-1]/L
    K = (np.cos(alpha*L) - np.cosh(alpha*L))/(np.sin(alpha*L) - np.sinh(alpha*L))
    disp = ((np.cosh(alpha*x) + np.cos(alpha*x)) - K *(np.sinh(alpha*x) + np.sin(alpha*x)))
    return disp
def modalBM(mode,x,L = 120):
    global alphaL
    alpha = alphaL[mode-1]/L
    K = (np.cos(alpha*L) - np.cosh(alpha*L))/(np.sin(alpha*L) - np.sinh(alpha*L))
    BM = (alpha**2)*((np.cosh(alpha*x) - np.cos(alpha*x)) - K *(np.sinh(alpha*x) - np.sin(alpha*x)))
    return BM
def modalSF(mode,x,L = 120):
    global alphaL
    alpha = alphaL[mode-1]/L
    K = (np.cos(alpha*L) - np.cosh(alpha*L))/(np.sin(alpha*L) - np.sinh(alpha*L))
    SF = (alpha**3)*((np.sinh(alpha*x) + np.sin(alpha*x)) - K *(np.cosh(alpha*x) - np.cos(alpha*x)))
    return SF
                                                        # forces
def fRad(A,B,q,qd,T,w):
    dt = T[1] - T[0]
    damp  = 0
    for i in range(len(qd)):
        damp += qd[len(qd)-1-i] * B[i]
    #print(damp*dt)
    #print(A*w**2*q )
    #time.sleep(10)
    return A*w**2*q - damp*dt
def fExt(F,P,t,w):
    fmod = 0.5*(1 - np.cos(w*t/2))
    if t>= 2*np.pi/w:
        fmod = 1
    return F * np.cos(w*t + P)*fmod
                                                        # integrands
def I1(P,w,T,i):
    S = (P[1:i+1] - P[0:i])/(T[1:i+1] - T[0:i])
    return P[i]*np.sin(w*T[i])/w + sum(S*(np.cos(w*T[1:i+1]) - np.cos(w*T[0:i])))/(w**2)
    

def I2(P,w,T,i):
    S = (P[1:i+1] - P[0:i])/(T[1:i+1] - T[0:i])
    return (P[0] - P[i]*np.cos(w*T[i]))/w + sum(S*(np.sin(w*T[1:i+1]) - np.sin(w*T[0:i])))/(w**2)
        
                                                         # Duhamel integral
def duhamel(A,B,F,P,T,mode,m,w,we,C33,L = 120):
    q = np.zeros(len(T))
    qdot = np.zeros(len(T))
    p = np.zeros(len(T))
    radf = np.zeros(len(T))
    Exf = np.zeros(len(T))
    for i in range(1,len(T)):
        radf[i] = fRad(A,B,q[i-1],qdot[0:i],T[0:2],we)*120.001
        Exf[i] = fExt(F,P,T[i],we)
        p[i] =  radf[i] + fExt(F,P,T[i],we) * modaldisp(mode,L/2,L)  + C33*q[i-1]
        q[i] = (I1(p,w,T,i)*np.sin(w*T[i]) - I2(p,w,T,i)*np.cos(w*T[i]))/(m*w)
        qdot[i] = (I1(p,w,T,i)*np.cos(w*T[i]) + I2(p,w,T,i)*np.sin(w*T[i]))/(m)
        #print(i)
        #print("I1")
        #print(I1(p,w,T,i))
        #print("Radiation force")
        #if mode == 1:
        #    print(radf[i])
        #print("Excitation force")
        #print(fExt(F,P,T[i],we))
        #print("Generalised Force")
        #print(p[i])
        #print("q")
        #print(q[i])
        #time.sleep(10)
    return q,p,radf,Exf
