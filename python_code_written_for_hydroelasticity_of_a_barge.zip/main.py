import os
os.chdir("A:\PAPERS\greenwater_with_flexure/code python")
import paper
import numpy as np
import matplotlib.pylab as plt
stiffa = np.array([0.01])
for i2main in range(len(stiffa)):
    print(i2main)
    Tpa = np.array([8.77])
    #Tpa = np.zeros(50)
    #for i3 in range(len(Tpa)):
    #    Tpa[i3] = 4.4 +(i3)*0.5
    #BMa = np.zeros((len(Tpa),2))
    #SFa = np.zeros((len(Tpa),2))
    for imain in range(len(Tpa)):
        Tp = Tpa[imain]
        omega  = 2*np.pi/Tp
                                                # inputs and prelimnary calculations
        A = np.zeros(6)
        F = np.zeros(6)
        P = np.zeros(6)

        A = paper.interp('A:/PAPERS/greenwater_with_flexure/code python/A.csv',omega)
        F = paper.interp('A:/PAPERS/greenwater_with_flexure/code python/F.csv',omega)
        P = paper.interp('A:/PAPERS/greenwater_with_flexure/code python/P.csv',omega)

        P = P * np.pi/180
        #P = P * 180/np.pi
        stiff = stiffa[i2main]
        if stiff <0.01:
            step = 150
            times = 400
        else:
            step = 60
            times = 200
        
        dt = Tp/step
        
        T = np.zeros(times)
        for i in range(times):
            T[i] = i*dt


        Ainf = np.zeros(6)
        Btau = np.zeros((6,len(T)))
        for i in range(1,7):
            Ainf[i-1],Btau[i-1][0:] = paper.AnB('A:/PAPERS/greenwater_with_flexure/code python/B.csv',i,A[i-1],T,omega)
            #plt.plot(T,Btau[i-1][0:]/(1025*9.81*120*120))
        #plt.show()

        modesh = np.zeros((6,121))
        for mode in range(1,7):
            for i in range(121):
                modesh[mode-1][i] = paper.modaldisp(mode,i)
            #plt.plot(range(121),modesh[mode-1][0:])
        #plt.show()




        L = 120
        B = 12
        Td = 6 #draught
        MOI = 178.71
        Area = L*B*Td*1025/(L*7850)
        
        MOE = stiff * (1025 * 9.81 * L**5) / MOI
        C33 = L*B*9.81*1025
        #m = 7850 *Area
        m = 1025*12*6
        
        rhos = 7850
        alphaL = np.array([4.730, 7.853, 10.996, 14.137, 17.278, 20.420])
        alpha = alphaL/L


        omegan = np.sqrt((MOE*MOI*alpha**4/m))
        #fortran omegan
        #omegan =((alpha)**2)*np.sqrt(MOE*MOI/rhos*Area)*np.sqrt(1 + ((C33/L)/(MOE*MOI*(alpha)**4)))
        #P = P * (180/np.pi)**2
        #omegan = ((AlphaL/Length)**2)*sqrt(MOE*MOI/rhos*csArea)*sqrt(1 + ((c33/length)/(MOE*MOI*(AlphaL/length)**4)))


        m = m*120





        q = np.zeros((6,len(T)))
        p = np.zeros((6,len(T)))
        radf = np.zeros((6,len(T)))
        EXT = np.zeros((6,len(T)))
        fig, axs = plt.subplots(6,1)
        axs = axs.ravel()

        for mode in range(1,7):
            q[mode-1][0:],p[mode-1][0:],radf[mode-1][0:],EXT[mode-1][0:] = paper.duhamel(A[mode-1],Btau[mode-1][0:],F[mode-1],P[mode-1],T,mode,m,omegan[mode-1],omega,C33)
            
            axs[mode-1].plot(T,q[mode-1][0:])
        plt.show()
                      # BM at L=60
        BM = np.zeros(len(T))
        for i in range(len(T)):  
            BM[i] = 0
            for mode in range(1,7):
                BM[i] += paper.modalBM(mode,60) *q[mode-1][i]
        BM =BM * MOE*MOI /(1025*L*B*Td *9.81*1*45)
        
        #plt.plot(range(200),BM)
        #plt.show()
                            # SF at L=30
        SF = np.zeros(len(T))
        for i in range(len(T)):  
            SF[i] = 0
            for mode in range(1,7):
                SF[i] += paper.modalSF(mode,30) *q[mode-1][i]
        SF =SF * MOE*MOI*120 /(1025*L*B*Td *9.81*1*45)
        #plt.plot(range(200),SF)
        #plt.show()
        
        np.savetxt("A:\PAPERS\greenwater_with_flexure\code python" + "\stiff" + str(i2main) + "\BM\BM"+str(Tpa[imain])+".txt", BM.reshape((len(T),1)), newline="\n ")
        np.savetxt("A:\PAPERS\greenwater_with_flexure\code python" + "\stiff" + str(i2main) + "\SF\SF"+str(Tpa[imain])+".txt", SF.reshape((len(T),1)), newline="\n ")
        BMa[imain][0:] = [Tp,max(BM[150:])]
        SFa[imain][0:] = [Tp,max(SF[150:])]
    np.savetxt("A:\PAPERS\greenwater_with_flexure\code python"+ "\stiff"+str(i2main) +"\BMalltp.txt", BMa, newline="\n ")
    np.savetxt("A:\PAPERS\greenwater_with_flexure\code python"+ "\stiff"+str(i2main) +"\SFalltp.txt", SFa, newline="\n ")

